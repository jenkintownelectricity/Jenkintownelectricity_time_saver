import { EstimateList } from '@/components/estimates/estimate-list'

export default function EstimatesPage() {
  return (
    <div className="container mx-auto py-8">
      <EstimateList />
    </div>
  )
}
