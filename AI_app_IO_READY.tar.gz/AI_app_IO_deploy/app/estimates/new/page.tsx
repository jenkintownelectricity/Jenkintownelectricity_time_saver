import { EstimateForm } from '@/components/estimates/estimate-form'

export default function NewEstimatePage() {
  return (
    <div className="container mx-auto py-8">
      <EstimateForm />
    </div>
  )
}
