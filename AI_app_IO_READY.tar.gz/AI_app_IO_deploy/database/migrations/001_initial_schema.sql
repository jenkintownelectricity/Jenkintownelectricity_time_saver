-- ============================================================================
-- Migration 001: Initial Schema Setup
-- ============================================================================
-- This is the same as schema.sql but versioned for migration tracking
-- Run Date: Initial setup
-- ============================================================================

-- (Same content as schema.sql - this file exists for migration version control)
-- For initial setup, you can run schema.sql directly
-- This file is here for completeness and future reference

-- See: ../schema.sql for the complete schema
